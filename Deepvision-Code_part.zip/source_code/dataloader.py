import io
import os
import smtplib
from email.message import EmailMessage
from typing import Iterable, Optional, Tuple

import cv2
import numpy as np
import torch
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter, maximum_filter
from scipy.io import loadmat

# Shared preprocessing constants
IMG_SIZE: Tuple[int, int] = (512, 512)
MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]


def load_image_from_bytes(b: bytes) -> Image.Image:
    """Load an RGB PIL image from raw bytes."""
    return Image.open(io.BytesIO(b)).convert("RGB")


def preprocess_image_pil(img: Image.Image, device: torch.device) -> torch.Tensor:
    """Resize to IMG_SIZE, normalize with ImageNet stats, return (1,C,H,W) tensor."""
    img_resized = img.resize(IMG_SIZE, Image.BILINEAR)
    arr = np.asarray(img_resized).astype(np.float32) / 255.0
    arr = (arr - np.array(MEAN, dtype=np.float32)) / np.array(STD, dtype=np.float32)
    # HWC -> CHW
    chw = np.transpose(arr, (2, 0, 1))
    t = torch.from_numpy(chw).unsqueeze(0).to(device)
    return t


def tensor_density_to_numpy(t: torch.Tensor) -> np.ndarray:
    """Convert (1,1,H,W) or (1,H,W) density tensor to (H,W) float32 numpy."""
    if t.dim() == 4:
        t = t[0, 0]
    elif t.dim() == 3:
        t = t[0]
    arr = t.detach().cpu().float().numpy()
    return arr


def _draw_gaussian(map2d: np.ndarray, x: int, y: int, sigma: float):
    """Add a single Gaussian centered at (x, y) into map2d in-place."""
    h, w = map2d.shape
    if x < 0 or y < 0 or x >= w or y >= h:
        return
    # Create an impulse and blur
    impulse = np.zeros_like(map2d, dtype=np.float32)
    impulse[y, x] = 1.0
    map2d += gaussian_filter(impulse, sigma=sigma, mode="constant")


def density_from_points(image_size: Tuple[int, int], points: np.ndarray, sigma: float = 15.0) -> np.ndarray:
    """Generate a density map from head points using Gaussian kernels.
    points: Nx2 array of (x, y) coordinates in pixel space.
    """
    w, h = image_size
    dm = np.zeros((h, w), dtype=np.float32)
    if points is None:
        return dm
    pts = np.asarray(points)
    if pts.size == 0:
        return dm
    # Ensure (x, y) order
    for p in pts:
        x = int(np.clip(p[0], 0, w - 1))
        y = int(np.clip(p[1], 0, h - 1))
        _draw_gaussian(dm, x, y, sigma)
    return dm


def _to_bgr(img: Image.Image) -> np.ndarray:
    arr = np.asarray(img.convert("RGB"))
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


def _to_pil(bgr: np.ndarray) -> Image.Image:
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb)


def density_to_overlay(img: Image.Image, density: np.ndarray, alpha: float = 0.45) -> Image.Image:
    """Overlay a colored heatmap of density on top of the image."""
    base_bgr = _to_bgr(img)
    d = density.astype(np.float32)
    if d.size == 0:
        return img
    if d.max() > 0:
        d_norm = (d / (d.max() + 1e-6) * 255.0).astype(np.uint8)
    else:
        d_norm = np.zeros_like(d, dtype=np.uint8)
    heat = cv2.applyColorMap(d_norm, cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(base_bgr, 1.0, heat, alpha, 0)
    return _to_pil(overlay)


def overlay_points_on_image(img: Image.Image, points: np.ndarray, color=(0, 255, 0), radius: int = 3) -> Image.Image:
    im = img.copy()
    draw = ImageDraw.Draw(im)
    if points is not None:
        for p in np.asarray(points):
            x, y = int(p[0]), int(p[1])
            draw.ellipse((x - radius, y - radius, x + radius, y + radius), outline=tuple(color), width=2)
    return im


def find_head_peaks(density: np.ndarray, thresh: float = 0.0001, neighborhood: int = 3) -> np.ndarray:
    """Detect local maxima in the density map (optional helper)."""
    if density is None or density.size == 0:
        return np.zeros((0, 2), dtype=np.float32)
    d = density.copy()
    d[d < thresh] = 0
    max_f = maximum_filter(d, footprint=np.ones((neighborhood, neighborhood)))
    peaks = (d == max_f) & (d > 0)
    ys, xs = np.where(peaks)
    return np.stack([xs, ys], axis=1).astype(np.float32)


def send_email(*, subject: str, body: str, to_email: str, from_email: str, smtp_server: str, smtp_port: int, smtp_user: str, smtp_password: str, attachment_path: Optional[str] = None) -> bool:
    """Send an email with an optional attachment via SMTP."""
    if not to_email or not from_email:
        raise ValueError("to_email and from_email are required")
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = to_email
    msg.set_content(body)

    if attachment_path and os.path.exists(attachment_path):
        with open(attachment_path, "rb") as f:
            data = f.read()
        maintype, subtype = "image", "jpeg"
        if attachment_path.lower().endswith(".png"):
            maintype, subtype = "image", "png"
        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=os.path.basename(attachment_path))

    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        if smtp_user:
            server.login(smtp_user, smtp_password)
        server.send_message(msg)
    return True


def read_shanghaitech_points_from_mat(mat_path: str) -> np.ndarray:
    """Read GT points from a ShanghaiTech-style .mat file robustly.

    Supports common variants:
      - data['image_info'][0,0]['location'][0,0] -> (N,2)
      - data['image_info'][0,0][0,0][0] -> (N,2)
      - any array value of shape (N,2)
    Returns (N,2) float32 array or empty array if not found.
    """
    try:
        data = loadmat(mat_path)
    except Exception:
        return np.zeros((0, 2), dtype=np.float32)

    pts = None
    try:
        if 'image_info' in data:
            info = data['image_info']
            # Case 1: has 'location' field
            try:
                loc = info[0, 0]['location']
                # sometimes another layer [0,0]
                if isinstance(loc, np.ndarray) and loc.size > 0 and isinstance(loc[0, 0], np.ndarray):
                    pts = loc[0, 0]
                else:
                    pts = loc
            except Exception:
                # Case 2: older indexing
                try:
                    pts = info[0, 0][0, 0][0]
                except Exception:
                    pts = None
    except Exception:
        pts = None

    # Fallback: scan for a (N,2)-shaped array among values
    if pts is None:
        for v in data.values():
            if isinstance(v, np.ndarray) and len(v.shape) == 2 and v.shape[1] == 2:
                pts = v
                break

    if pts is None:
        return np.zeros((0, 2), dtype=np.float32)
    pts = np.asarray(pts, dtype=np.float32)
    if pts.ndim != 2 or pts.shape[1] != 2:
        return np.zeros((0, 2), dtype=np.float32)
    return pts
